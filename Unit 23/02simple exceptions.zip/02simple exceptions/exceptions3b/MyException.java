
/**
* MyException is now a separate class in its own right
 **/
class MyException extends Exception
{
    private int m;
    
    public MyException(int m)
    {
        super ("parameter of constructor should be positive, but was " + m);
        this.m = m;
    }
}