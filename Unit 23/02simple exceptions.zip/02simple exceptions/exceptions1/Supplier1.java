
/**
 * 1. Simple class to illustrate exception syntax 
 * @author Mick Wood
 * @version 02/04
 */
public class Supplier1
{
    private int n;
    private String name;
    
    /** @param name a name for the supplier object, to be used in messages.
     *  @param n an integer which controls whether 'method' throws an exception 
     *  (n < 0) or not.
     */
    public Supplier1(String name, int n)
    {
        this.name = name;
        this.n = n;
    }
    
/** this method handles its own exception � nobody else needs to know**/
    public void method()
    {
        try
        {
            System.out.println ("Start of method. in supplier " + name);
            if (n < 0) 
            {
                throw new Exception ("parameter of constructor should be positive, but was " + n);
            }
            System.out.println ("Method in " + name + " terminated normally.\n");
        }
        catch (Exception e)
        {
            System.out.println ("Method in " + name + " terminated with exception.");
            System.out.println (e.toString() + '\n');
        }
    }            
}
