/** As the try...catch.. is in supplier � client needs to do nothing further
 * @author Mick Wood
 * @version 02/04
 */
public class Client1
{
    // instance variables - replace the example below with your own
    private Supplier1 supplier1, supplier2;

    public Client1(String name)
    {
        
        supplier1 = new Supplier1("supplier1", 10);
        supplier2 = new Supplier1 ("supplier2", -10);
        System.out.println ("Client " + name + " has created two Suppliers.");
                
        supplier1.method();
        supplier2.method();
        
        System.out.println ("Life goes on...!!");
        System.out.println ("Client terminates normally.");
    }
}

