/** No try...catch.. in supplier � exception thrown to client.
 * Client handles exception using try... catch ..
 * @author Mick Wood
 * @version 02/04  */
public class Client1
{
    private Supplier1 supplier1, supplier2;
    private String name;

    /**
     * Client creates two suppliers.  Catches exception thrown by second one.
     * @param name a name used in diagnostic messages.
     */
    public Client1(String name)
    {
        this.name = name;
        supplier1 = new Supplier1("supplier1", 10);
        supplier2 = new Supplier1 ("supplier2", -10);

        System.out.println (name + " has created two suppliers.");        
        try
        {
            supplier1.method();
            supplier2.method();
            
            System.out.println (name + " terminates normally.");
        }                
        catch (Exception e)
        {
            System.out.println ("Method in " + name + " terminated with exception.");
            System.out.println (e.toString() + '\n');
        }
        System.out.println ("Life goes on...!!");
    }
}
