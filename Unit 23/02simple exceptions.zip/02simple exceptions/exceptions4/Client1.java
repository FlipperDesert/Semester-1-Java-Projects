/**
 * 4. Further demonstration of exception propagation. 
 * No try...catch.. in supplier - throw it to client.
 * No try...catch.. in client - throw to run time system
 * @author Mick Wood
 * @version 02/04
 */
public class Client1
{
    private Supplier1 supplier1, supplier2;
    private String name;

    public Client1(String name) throws MyException
    {
        this.name = name;
        supplier1 = new Supplier1("supplier1", 10);
        supplier2 = new Supplier1 ("supplier2", -10);
        
        System.out.println (name + " has created two suppliers.");
 	    supplier1.method();
        supplier2.method();
        
        //We won't get here.....
        System.out.println ("Life goes on...!!");
        System.out.println (name + " has terminated normally.");        
    }
}
