/**3b. Further examples to illustrate exception propagation 
 * This version uses a customised exception class.
 * @author Mick Wood
 * @version 02/04
 */
public class Supplier1
{
    private int n;
    private String name;

    /* 
     * @param name a name for the supplier object, to be used in messages.
     * @param n an integer which controls whether 'method' throws an exception 
     * (n<0) or not.
     */        
    public Supplier1(String name, int n)
    {
        this.name = name;
        this.n = n;
    }
    
    /**MyException is an exception defined just for this application
     * method does not handle the exception so must declare this in header **/ 
    public void method() throws MyException
    {
       System.out.println ("Start of method. in supplier " + name);
       if (n < 0) 
       {
           throw new MyException (n);
       }
       System.out.println ("Method in " + name + " terminated normally.\n");
    }            
} // check that moving this to after MyException class makes no difference


/**Java will allow more than one class to be declared in the same file
* MyException is in a sense local � see BlueJ class diagram
* It can also be included in text for above class or its own separate class **/
class MyException extends Exception
{
    private int n;
    
    public MyException(int n)
    {
        super ("parameter of constructor should be positive, but was " + n);
        this.n = n;
    }
}


