
/**
 * Testr Class is a client of Library 
 * Explores approaches to error handling.
 * No changes to version 1a
 * @author Mick Wood, amended Olenka Marczyk 
 * @version 1b - Error Avoidance (Programming by contract)
 */
public class Tester
{
    private Library library = new Library();
    
    Member m1 = new Member ("Fred");
    Member m2 = new Member ("Amit");
    Member m3 = new Member ("Olek");  // not added to library
    
    Book b1 = new Book ("Wuthering Heights");
    Book b2 = new Book ("1984");
    Book b3 = new Book ("Brave New World");
    Book b4 = new Book ("The Book Thief");
    Book b5 = new Book ("Jane Eyre"); // not added to library
    
    public Tester()
    {
        System.out.println ("A version of Library.");
        library.addMember (m1); library.addMember (m2);
        // m3 not added to library
        library.addBook (b1); library.addBook (b2); library.addBook (b3);
        library.addBook (b4);
        // b5 not added to library
        System.out.println("***********Members***************");
        System.out.println(library.listMembers());
        System.out.println("*******Available books***********");
        System.out.println(library.listAllBooks());
    }

    
    public void doTest ()
    {
        
        System.out.println("********** Responsible Client ***********");
        /** Responsible client: Test precondition on lendBook **/
        performLoan(m1,b1);    // see local method below
        performLoan(m1,b2); // second book to same member
        performLoan(m2, b1); // same book to another member - not allowed
        performLoan(m3, b3); // loan to non-member - not allowed
        performLoan(m1, b5); // book not in library

//         //Return book - which is on loan
//         System.out.println ("\n\nReturn Book");
//         if (library.isOnLoan(m1,b1))
//         {
//             library.returnBook(m1,b1);
//             System.out.println (b1.getTitle() + " was returned by " 
//                     + m1.getName()); 
//         }
//         else
//         {
//             System.out.println (b1.getTitle() + " not on loan to " 
//                     + m1.getName());
//         } 
// 
//         //Return book - which is not on loan
//         if (library.isOnLoan(m1,b4))
//         {
//             library.returnBook(m1,b4);
//             System.out.println (b4.getTitle() + " was returned by " 
//                     + m1.getName()); 
//         }
//         else
//         {
//             System.out.println (b4.getTitle() + " not on loan to " 
//                     + m1.getName());
//         } 


        System.out.println("Irresponsible client : "); 
        System.out.println("********Irresponsible client*************");
        library.lendBook (m2,b1);      //b1 already loaned
        System.out.println (b1.getTitle() + " was loaned to " + m2.getName()); 
        library.lendBook (m2, b5);      //b5 not library book
        System.out.println (b5.getTitle() + " was loaned to " + m2.getName()); 
        library.lendBook (m3,b4);      //m3 member oflibrary
        System.out.println (b4.getTitle() + " was loaned to " + m3.getName());
        System.out.println("***********Available books***************");
        System.out.println(library.listAvailableBooks());
    }
    
    private void performLoan(Member m,Book b)
    {
        if (!library.isMember(m))
        {
            System.out.println (m.getName() + " not a member of this library " );
        }
        else if (!library.isBook(b))
        {
            System.out.println (b.getTitle()+ " not a book in this library " );
        }
        else if (!library.bookIsAvailable (b))
        {
            System.out.println (b.getTitle() + " not available for loan to " + m.getName());
        }
        else 
        {            
            library.lendBook (m, b);      // this is what we want to do
            System.out.println (b.getTitle() + " was loaned to " + m.getName());
        }
    }
}
