
/**
 * Testr Class is a client of Library 
 * Explores approaches to error handling.
 * No changes to version 1a
 * @author Mick Wood, amended Olenka Marczyk 
 * @version 1b - Error Avoidance (Programming by contract)
 */
public class Tester
{
    private Library library = new Library();

    Member m1 = new Member ("Fred");
    Member m2 = new Member ("Amit");
    Member m3 = new Member ("Olek");  // not added to library
    Member m4 = new Member ("Jan");

    Book b1 = new Book ("Wuthering Heights");
    Book b2 = new Book ("1984");
    Book b3 = new Book ("Brave New World");
    Book b4 = new Book ("The Book Thief");
    Book b5 = new Book ("Jane Eyre"); // not added to library

    public Tester()
    {
        System.out.println ("A version of Library.");
        library.addMember (m1); library.addMember (m2);
        library.addMember (m4);
        // m3 not added to library
        library.addBook (b1); library.addBook (b2); library.addBook (b3);
        library.addBook (b4);
        // b5 not added to library
        System.out.println("***********Members***************");
        System.out.println(library.listMembers());
        System.out.println("*******Available books***********");
        System.out.println(library.listAllBooks());
    }

    public void doTest ()
    {

        System.out.println("********** Responsible Client ***********");
        /** Responsible client: Test precondition on lendBook **/
        doLoan(m1,b1);     // see local method below
        doLoan(m1,b2);     // second book to same member
        doLoan(m2,b1);     // same book to another member - not allowed
        doLoan(m3,b3);     // loan to non-member - not allowed
        doLoan(m1,b5);     // book not in library
        m4.addFine(10);
        doLoan(m4,b4);     // member has fines
        m4.payFine(10);
        System.out.println("Fine paid");
        doLoan(m4,b4); // member has no fines

        System.out.println ("\n\nReturn Book");
        //Return book - which is on loan
        System.out.println(doReturn(m1,b1));

        //Return book - which is not on loan
        System.out.println(doReturn(m1,b4));

        System.out.println("As a responsible programmer you would not write this code");
        System.out.println("\nIrresponsible client : ");
        System.out.println("********Irresponsible client*************");
        library.lendBook (m2,b1);      //b1 already loaned
        System.out.println (b1.getTitle() + " was loaned to " + m2.getName()); 
        library.lendBook (m2,b5);      //b5 not library book
        System.out.println (b5.getTitle() + " was loaned to " + m2.getName()); 
        library.lendBook (m3,b4);      //m3 member oflibrary
        System.out.println (b4.getTitle() + " was loaned to " + m3.getName());
        System.out.println("***********Available books***************");
        System.out.println(library.listAvailableBooks());
    }

    private void doLoan(Member m,Book b)
    {
        if (!library.isMember(m))
        {
            System.out.println (m.getName() + " not a member of this library " );
        }
        else if (!library.isBook(b))
        {
            System.out.println (b. getTitle() + " not a book in this library " );
        }
        else if (!library.bookIsAvailable (b))
        {
            System.out.println (b.getTitle() + " not available for loan to " + m.getName());
        }
        else if (!library.noFines(m))
        {
            System.out.println (m.getName() + " has fines of �" + m.getFines());
        }
        else 
        {            
            library.lendBook (m,b);      // this is what we want to do
            System.out.println (b.getTitle() + " was loaned to " + m.getName());
        }
    }

    // uses a return rather than output direct to terminal window

    private String doReturn(Member m, Book b)
    {
        //Return book - which is on loan
        if (library.isOnLoan(m,b))
        {
            library.returnBook(m,b);
            return b.getTitle() + " was returned by " 
            + m.getName(); 
        }
        else
        {
            return b.getTitle() + " not on loan to " 
            + m.getName();
        } 
    }
}
