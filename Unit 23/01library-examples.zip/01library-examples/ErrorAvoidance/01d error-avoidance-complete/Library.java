import java.util.*;
/**
 * Class Library explores approaches to error handling.
 * Library now lists all books, book knows whether it is available or not
 * (see changes to Book class)
 * @author Mick Wood 
 * @version 1 - Error Avoidance(Programming by Contract)
 */
public class Library
{
    private ArrayList<Member> members = new ArrayList<Member>();
    private ArrayList<Book> books = new ArrayList<Book>();
    
    public void addMember (Member member) 
    {
        members.add (member);
    }
    
    public void addBook (Book book) 
    {
        books.add(book);
    }
    
     
    /**
     * Loan a Book to a Member
     * PRECONDITION: is member and book is available to be loaned, i.e:
     *               isMember(m) && isBook(b) && bookIsAvailable(b)
     *               && noFines(m)
     * @param b the Book to be loaned
     * @param m the Member to loan the Book
     */
    public void lendBook (Member m, Book b)
    {
        m.loanBook (b);
        b.setUnavailable();
    }
    
    
    /** return book
     * PRECONDITION: isOnLoan(Member m, Book b)
     */
    public void returnBook (Member m, Book b)
    {
        m.returnBook (b);
        b.setAvailable();
    }

    public boolean isOnLoan(Member m, Book b)
    {
        return m.hasBook(b);
    }
    
    public boolean isMember(Member m)
    {
        return members.contains(m);
    }
    
    public boolean isBook(Book b)
    {
        return books.contains(b);
    }
    
    public boolean bookIsAvailable (Book book) 
    {
        return book.isAvailable();
    }
    
    public boolean noFines(Member m)
    {
        return !m.hasFines();  //m.hasFines()== false or m.getFines() <=0
    }
    
    public String listAvailableBooks()
    {
        String s = "";
        for (Book temp : books)
        {
            if (temp.isAvailable())
            {
                s = s + temp.getTitle()+ "\n";
            }
        }
        return s;
    }
    
    public String listMembers()
    {
        String s = "";
        for (Member temp : members)
        {
            s = s + temp.getName()+ "\n";
        }
        return s; 
    }
    
    public String listAllBooks()
    {
        String s = "";
        for (Book temp : books)
        {
            s = s + temp.getTitle()+ "\n";
        }
        return s; 
    }  
}
