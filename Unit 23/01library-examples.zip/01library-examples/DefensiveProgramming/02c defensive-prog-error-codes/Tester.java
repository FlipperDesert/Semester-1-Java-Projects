
/**
 * Client Class for Library example.
 * Explores approaches to error handling.
 * 
 * @author Mick Wood, amended by Olenka Marczyk 10/03/08
 * @version 2 - Defensive Programming with Error Codes
 */
public class Tester
{
    private Library library = new Library();
    
    Member m1 = new Member ("Fred");
    Member m2 = new Member ("Amit");
    Member m3 = new Member ("Olek");
    Member m4 = new Member ("jan");
    
    Book b1 = new Book ("Wuthering Heights");
    Book b2 = new Book ("1984");
    Book b3 = new Book ("Brave New World");
    Book b4 = new Book ("The Book Thief");
    Book b5 = new Book ("Jane Eyre"); 
    
    public Tester()
    {
        System.out.println ("A version of Library.");
        library.addMember (m1); library.addMember (m2);library.addMember (m4);
        // m3 not added to library
        library.addBook (b1); library.addBook (b2); library.addBook (b3);
        library.addBook (b4);
        // b5 not added to library
        System.out.println("***********Members***************");
        System.out.println(library.listMembers());
        System.out.println("*******Available books***********");
        System.out.println(library.listAllBooks());
    }
    
    public void doTest ()
    {

        int success = library.lendBook (m1,b1);
        System.out.print (b1.getTitle() + " for loan to " + m1.getName()
            + " : " );
        if (success == 0)
        {
           System.out.println ("Loan successful");
        }
        else if (success == 1)
        {
            System.out.println ("No such member");
        }
        else if (success == 2)
        {
            System.out.println ("Not library book");
        }
        else if (success == 3)
        {
            System.out.println ("Book not available");
        }
        else if (success == 4)
        {
            System.out.println ("Member has fines");
        }
        else
        {
            System.out.println ("Error");
        }    
        
        //Clearly a bad way to do it
        //Here is an alternative which uses a local method getResult()    
        success = library.lendBook (m1,b2);
        System.out.println (b2.getTitle() + " for loan to " + m1.getName()
            + " : " + getResult(success));
       
        success = library.lendBook (m2, b2);
        System.out.println (b2.getTitle() + " for loan to " + m2.getName()
            + " : " + getResult(success));
            
        success = library.lendBook (m2, b1);
        System.out.println (b1.getTitle() + " for loan to " + m2.getName()
            + " : " + getResult(success));
    
        success = library.lendBook (m2,b5);
        System.out.println (b5.getTitle() + " for loan to " + m2.getName()
            + " : " + getResult(success));
        
        success = library.lendBook (m3,b4);
        System.out.println (b4.getTitle() + " for loan to " + m3.getName()
            + " : " + getResult(success));
            
        /*** NOTE - there is nothing to force us to test the return value of lendBook, 
         * e.g. we can get away with:
         */
        library.lendBook (m2,b2);
        System.out.println ("Ignoring result:--  " + b2.getTitle() + " for loan to " 
                    + m2.getName()+ " : Successful");
        System.out.println("***********Available books***************");
        System.out.println(library.listAvailableBooks());
        
        System.out.println ("\n\nReturn Book");
        //Return book - which is on loan
        System.out.println(doReturn(m1,b1));

        //Return book - which is not on loan
        System.out.println(doReturn(m1,b4));
    }
    
    private String getResult(int rr)
    {
        if (rr == 0)
        {
           return "Loan successful";
        }
        else if (rr == 1)
        {
            return "No such member";
        }
        else if (rr == 2)
        {
            return "Not library book";
        }        
        else if (rr == 3)
        {
            return "Book not available";
        }
        
        else
        {
            return "Error";
        }
    }
    
    private String doReturn(Member m, Book b)
    {
        //Return book - which is on loan
        if (library.isOnLoan(m,b))
        {
            library.returnBook(m,b);
            return b.getTitle() + " was returned by " 
            + m.getName(); 
        }
        else
        {
            return b.getTitle() + " not on loan to " 
            + m.getName();
        } 
    }
}
