import java.util.*;
/**
 * Class Library explores approaches to error handling.
 * 
 * @author Mick Wood, amended A.Marczyk 
 * @version 2 - Defensive Programming with Error Codes
 * Based on Library 1b
 */
public class Library
{
    private ArrayList<Member> members = new ArrayList<Member>();
    private ArrayList<Book> books = new ArrayList<Book> ();
    
    public void addMember (Member member) {members.add (member);}
    public void addBook (Book book) {books.add (book);}

    /**
     * Loan a Book to a Member
     *  
     * @param b the Book to be loaned
     * @param m the Member to loan the Book
     * 
     * @return true if book was loaned successfully, false otherwise
     */
    public boolean lendBook (Member m,Book b)
    {
        if (b.isAvailable() && isMember(m) && isBook(b)&& !m.hasFines())
        {            
            m.loanBook (b);
            b.setUnavailable();
            return true;
        }
        else {return false;}            
    }
     
    /** return book
     * PRECONDITION: isOnLoan(Member m, Book b)
     */
    public void returnBook (Member m, Book b)
    {
        m.returnBook (b);
        b.setAvailable();
    }

    public boolean isOnLoan(Member m, Book b)
    {
        return m.hasBook(b);
    }
    
    public boolean isMember(Member m)
    {
        return members.contains(m);
    }
    
    public boolean isBook(Book b)
    {
        return books.contains(b);
    }
    
    public String listAvailableBooks()
    {
        String s = "";
        for (Book temp : books)
        {
            if (temp.isAvailable())
            {
                s = s + temp.getTitle()+ "\n";
            }
        }
        return s;
    }
    
    public String listMembers()
    {
        String s = "";
        for (Member temp : members)
        {
            s = s + temp.getName()+ "\n";
        }
        return s; 
    }
    
    public String listAllBooks()
    {
        String s = "";
        for (Book temp : books)
        {
            s = s + temp.getTitle()+ "\n";
        }
        return s; 
    }
}
