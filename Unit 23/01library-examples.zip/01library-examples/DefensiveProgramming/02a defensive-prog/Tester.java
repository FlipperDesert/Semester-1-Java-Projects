
/**
 * Client Class for Library example.
 * Explores approaches to error handling.
 * 
 * @author Mick Wood 
 * @version 2 - Defensive Programming with Error Codes
 */
public class Tester
{
    private Library library = new Library();
    
    Member m1 = new Member ("Fred");
    Member m2 = new Member ("Amit");
    Member m3 = new Member ("Olek");  // not added to library
    Member m4 = new Member ("Jan");
    
    Book b1 = new Book ("Wuthering Heights");
    Book b2 = new Book ("1984");
    Book b3 = new Book ("Brave New World");
    Book b4 = new Book ("The Book Thief");
    Book b5 = new Book ("Jane Eyre"); // not added to library
    
    public Tester()
    {
        System.out.println ("A version of Library.");
        library.addMember (m1); library.addMember (m2);library.addMember (m4);
        // m3 not added to library
        library.addBook (b1); library.addBook (b2); library.addBook (b3);
        library.addBook (b4);
        // b5 not added to library
        System.out.println("***********Members***************");
        System.out.println(library.listMembers());
        System.out.println("*******Available books***********");
        System.out.println(library.listAllBooks());
    }

    
    public void doTest ()
    {
        System.out.println("********** Client - No need to be responsible***********");
        library.lendBook (m1, b1);     
        library.lendBook (m2, b2);
        // What happens here ?
        // should not be able to do these !
        library.lendBook (m2, b1);      // book already on loan
        library.lendBook (m3, b1);      // not member of library
        library.lendBook (m2, b5);      // book not in library
        m2.addFine(10);
        library.lendBook (m2, b3);
        m2.payFine(10);
        library.lendBook (m2, b3);
        // In practice, the client wants to have some idea of what is happening
        
        System.out.println ("\n\nReturn Book");
        //Return book - which is on loan
        System.out.println(doReturn(m1,b1));

        //Return book - which is not on loan
        System.out.println(doReturn(m1,b4));
    }
    
    private String doReturn(Member m, Book b)
    {
        //Return book - which is on loan
        if (library.isOnLoan(m,b))
        {
            library.returnBook(m,b);
            return b.getTitle() + " was returned by " 
            + m.getName(); 
        }
        else
        {
            return b.getTitle() + " not on loan to " 
            + m.getName();
        } 
    }
}
